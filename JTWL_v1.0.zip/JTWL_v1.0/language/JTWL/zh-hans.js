Blockly.JT_Int = '主板初始化';
Blockly.JT_MLC = '单色液晶显示字符';
Blockly.JT_MLV = '单色液晶显示变量';
Blockly.JT_SER = '舵机';
Blockly.JT_MTO = '电机';
Blockly.JT_ACC = '更新姿态数据';
Blockly.JT_ACC1 = 'X轴加速度';
Blockly.JT_ACC2 = 'Y轴加速度';
Blockly.JT_ACC3 = 'Z轴加速度';
Blockly.JT_ACD1 = 'X轴加速度方向';
Blockly.JT_ACD2 = 'Y轴加速度方向';
Blockly.JT_ACD3 = 'Z轴加速度方向';
Blockly.JT_ANG1 = 'X轴角速度';
Blockly.JT_ANG2 = 'Y轴角速度';
Blockly.JT_ANG3 = 'Z轴角速度';
Blockly.JT_MAG1 = 'X平面磁通量';
Blockly.JT_MAG2 = 'Y平面磁通量';
Blockly.JT_MAG3 = 'Z平面磁通量';
Blockly.JT_PRE = '气压(Pa)';
Blockly.JT_COO1 = '经度';
Blockly.JT_COO2 = '纬度';
Blockly.JT_POS1 = '定位精度';
Blockly.JT_POS2 = '可见北斗星数';
Blockly.JT_POS3 = '可见总星数';
Blockly.JT_POS4 = '海拔高度';
Blockly.JT_POS5 = '相对地速';
Blockly.JT_POS6 = '获取UTC时间';
Blockly.JT_POS7 = '获取UTC日期';
Blockly.JT_ENV = '更新环境数据';
Blockly.JT_ENV1 = '获取温度数据';
Blockly.JT_ENV2 = '获取湿度数据';
Blockly.JT_ENV3 = '获取甲醛数据';
Blockly.JT_ENV4 = '获取PM2.5含量';
Blockly.JT_LIG = '更新光照数据';
Blockly.JT_LIG1 = '紫外线强度数据';
Blockly.JT_LIG2 = '可见光强度数据';

Blockly.JT_INF = '学习红外编码';
Blockly.JT_SINF = '发送红外编码';
Blockly.JT_CLcd = '彩色液晶屏';

Blockly.JT_DAT = '数传';




















